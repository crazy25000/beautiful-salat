<?php

/**
 * Set up for the featured image widget.
 *
 * @package   beautiful-salat
 * @copyright Copyright (c) 2016, Nose Graze Ltd.
 * @license   GPL2+
 */
class Beautiful_Salat_Widget extends WP_Widget {

  /**
   * Register widget with WordPress.
   *
   * @access public
   * @since  1.0
   * @return void
   */
  public function __construct() {

    parent::__construct(
      'beautiful_salat_widget', // Base ID
      __( 'Beautiful Salat', 'beautiful-salat-widget' ), // Name
      array( 'description' => __( 'Prayer times for your website.', 'beautiful-salat-widget' ), ) // Args
    );

  }

  /**
   * Front-end display of widget.
   *
   * @see    WP_Widget::widget()
   *
   * @param array $args     Widget arguments.
   * @param array $instance Saved values from database.
   *
   * @access public
   * @since  1.0
   * @return void
   */
  public function widget( $args, $instance ) {

    $html = file($instance['url'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    echo "<link rel='stylesheet' type='text/css' href='wp-content/plugins/beautiful-salat/beautiful-salat.css'>";
    echo "<div class='prayer-times-box shadow-box'><h3 style='background-color:", $instance['size'], "'>Prayer Times</h3>";
    echo "<table class='prayer-table' border=0>";
    echo "<tr><td>Fajr <td>", $html[27];
    echo "<tr><td>Sunrise <td>", $html[33];
    echo "<tr><td>Dhuhr <td>", $html[39];
    echo "<tr><td>Ashr <td>", $html[45];
    echo "<tr><td>Maghrib <td>", $html[51];
    echo "<tr><td>Isha <td>", $html[57];
    echo "</table>";
    echo "</div>";

  }

  /**
   * Back-end widget form.
   *
   * @see    WP_Widget::form()
   *
   * @param array $instance Previously saved values from database.
   *
   * @access public
   * @since  1.0
   * @return void
   */
  public function form( $instance ) {
    $url         = ! empty( $instance['url'] ) ? $instance['url'] : 'http://islamicfinder.org/prayer-widget/104515/shafi/1/0';
    $size          = ! empty( $instance['size'] ) ? $instance['size'] : '#3498db';
    ?>
    <p>
      Instructions:
      <ol>
        <li>Visit <a href="http://islamicfinder.org/widgets/" target="_blank">here</a></li>
        <li>Scroll down to <b>Prayer times of your city</b></li>
        <li>Choose your country, state, city, and calculation method</li>
        <li>Select <b>Code</b></li>
        <li>Copy the full URL inside of <b>src="copyThisLink"</b></li>
        <li>Paste link and save</li>
      </ol>
    </p>

    <p>
      <label for="<?php echo $this->get_field_id( 'url' ); ?>"><?php _e( 'Islamic Finder URL:', 'beautiful-salat-widget' ); ?></label>
      <input class="widefat" id="<?php echo $this->get_field_id( 'url' ); ?>" name="<?php echo $this->get_field_name( 'url' ); ?>" type="text" value="<?php echo esc_attr( $url ); ?>">
    </p>

    <p>
      <label for="<?php echo $this->get_field_id( 'size' ); ?>"><?php _e( 'Hex Color Code:', 'beautiful-salat-widget' ); ?></label>
      <input class="widefat" id="<?php echo $this->get_field_id( 'size' ); ?>" name="<?php echo $this->get_field_name( 'size' ); ?>" type="text" value="<?php echo esc_attr( $size ); ?>">
    </p>
    <?php
  }

  /**
   * Sanitize widget form values as they are saved.
   *
   * @see WP_Widget::update()
   *
   * @param array $new_instance Values just sent to be saved.
   * @param array $old_instance Previously saved values from database.
   *
   * @return array Updated safe values to be saved.
   */
  public function update( $new_instance, $old_instance ) {
    $instance          = array();
    $instance['url'] = ( ! empty( $new_instance['url'] ) ) ? strip_tags( $new_instance['url'] ) : '';
    $instance['size']  = ( ! empty( $new_instance['size'] ) ) ? strip_tags( $new_instance['size'] ) : '';

    return $instance;
  }

}
