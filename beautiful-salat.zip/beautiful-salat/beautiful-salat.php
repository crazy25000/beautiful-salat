<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://freeislamictemplates.appspot.com
 * @since             1.0.0
 * @package           Beautiful_Salat
 *
 * @wordpress-plugin
 * Plugin Name:       Beautiful Salat
 * Plugin URI:        https://freeislamictemplates.appspot.com
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Nazim Ali
 * Author URI:        https://freeislamictemplates.appspot.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       beautiful-salat
 * Domain Path:       /languages
 */

// Include the widget.
include_once plugin_dir_path( __FILE__ ) . 'class-beautiful-salat-widget.php';

add_action( 'widgets_init', function(){
  register_widget( 'beautiful_salat_widget' );
});




