=== Beautiful Salat ===
Contributors: nazimali21
Donate link: https://freeislamictemplates.appspot.com
Tags: salat, salah, prayers, islam, muslim, daily prayers, namaz, azan, masjid, widget, beautiful, modern, elegant
Requires at least: 3.5
Tested up to: 4.6.1
Stable tag: 4.6.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

- Prayer times widget for your website:
- Uses Islamic Finder data
- Over 20,000 cities
- Automatically updates
- Customize title bakground color

== Working On ==
- Add color picker
- Add title input
- Add shadow toggle
- Add font/color options

== Installation ==

1. Upload plugin or install from plugin directory (recommended)
2. Activate
3. Add widget Beautiful Salat
4. Edit widget to change location

== Upgrade Notice ==
- None
== Screenshots ==

- screenshot-1.png
- screenshot-2.png
- screenshot-3.png

== Changelog ==

= 1.0 =
* Initial release

== Frequently Asked Questions ==
- None yet